<?
include 'libs/main/config.php';
include 'libs/main/session.php';
include 'libs/main/header.php';
?>
          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <?
            include 'ketua/index.php';
            include 'anggota/index.php';
            include 'bendahara/index.php';
            ?>

<?
include 'libs/main/footer.php';
?>